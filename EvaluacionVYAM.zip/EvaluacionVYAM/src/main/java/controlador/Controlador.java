package controlador;

public class Controlador{
	
	public static void main (String [] args) {

	}

}
