package modelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import controlador.Conexion;

public class AccionesCitaDAO {
	public static void insertarCita(Cita c) {

		try {
			Connection con = Conexion.getConnection();
			String q= "insert into citas (consultorio, doctor, horario_consulta, nombre_paciente) values (?,?,?,?)";
			PreparedStatement ps= con.prepareStatement(q);
			ps.setInt(1, c.getConsultorio());
			ps.setString(2, c.getDoctor());
			ps.setDate(3, (Date) c.getHorarioConsulta());
			ps.setString(4, c.getNombrePaciente());
			
			ps.executeUpdate();			
			System.out.println("Registro de cita exitosa");
		}catch(Exception e){
			System.out.println("Error de registro de citas");
			System.out.println(e.getMessage());				
		}
	}
	public static Cita consultarPorFecha(Date fecha) {
		
		Cita c = new Cita();
		try {
			Connection con = Conexion.getConnection();
			String q= "Select * from citas where horario_consulta =?";
			PreparedStatement ps= con.prepareStatement(q);
			ps.setDate(1, fecha);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				c.setConsultorio(rs.getInt(1));
				c.setDoctor(rs.getString(2));
				c.setHorarioConsulta(rs.getDate(3));
				c.setNombrePaciente(rs.getString(4));
			}
			System.out.println("Busqueda de citas por fecha exitosa");
		}catch(Exception e){
			System.out.println("Error de consulta de citas por fecha");
			System.out.println(e.getMessage());				
		}
		
		return c;
	}
	public static Cita consultarPorConsultorio(Integer consultorio) {
		
		Cita c = new Cita();
		try {
			Connection con = Conexion.getConnection();
			String q= "Select * from citas where consultorio = ?";
			PreparedStatement ps= con.prepareStatement(q);
			ps.setInt(1, consultorio);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				c.setConsultorio(rs.getInt(1));
				c.setDoctor(rs.getString(2));
				c.setHorarioConsulta(rs.getDate(3));
				c.setNombrePaciente(rs.getString(4));
			}
			System.out.println("Busqueda de citas por fecha exitosa");
		}catch(Exception e){
			System.out.println("Error de consulta de citas por fecha");
			System.out.println(e.getMessage());				
		}
		return c;
		
	}
	public static Cita consultarPorDoctor(String doctor) {
		
		Cita c = new Cita();
		try {
			Connection con = Conexion.getConnection();
			String q= "Select * from citas where doctor like \"%?%\"";
			PreparedStatement ps= con.prepareStatement(q);
			ps.setString(1, doctor);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				c.setConsultorio(rs.getInt(1));
				c.setDoctor(rs.getString(2));
				c.setHorarioConsulta(rs.getDate(3));
				c.setNombrePaciente(rs.getString(4));
			}
			System.out.println("Busqueda de citas por fecha exitosa");
		}catch(Exception e){
			System.out.println("Error de consulta de citas por fecha");
			System.out.println(e.getMessage());				
		}
		return c;
	}
	
}


