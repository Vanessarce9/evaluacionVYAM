package modelo;

import java.util.Date;

public class Cita {
	private Integer consultorio;
	private String doctor;
	private Date horarioConsulta;
	private String nombrePaciente;
	
	
	public Integer getConsultorio() {
		return consultorio;
	}
	public void setConsultorio(Integer consultorio) {
		this.consultorio = consultorio;
	}
	public String getDoctor() {
		return doctor;
	}
	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}
	public Date getHorarioConsulta() {
		return horarioConsulta;
	}
	public void setHorarioConsulta(Date horarioConsulta) {
		this.horarioConsulta = horarioConsulta;
	}
	public String getNombrePaciente() {
		return nombrePaciente;
	}
	public void setNombrePaciente(String nombrePaciente) {
		this.nombrePaciente = nombrePaciente;
	}
}
