package modelo;

public class Consultorio {
	private Integer numeroConsultorio;
	private Integer piso;
	
	
	public Integer getNumeroConsultorio() {
		return numeroConsultorio;
	}
	public void setNumeroConsultorio(Integer numeroConsultorio) {
		this.numeroConsultorio = numeroConsultorio;
	}
	public Integer getPiso() {
		return piso;
	}
	public void setPiso(Integer piso) {
		this.piso = piso;
	}
	
	

	

}
